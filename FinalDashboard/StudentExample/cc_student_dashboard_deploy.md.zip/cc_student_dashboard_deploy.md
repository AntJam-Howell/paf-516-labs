# PAF 516 Final Project — New Student Dashboard Deployment

## COMPLETE CONTEXT — READ BEFORE DOING ANYTHING

### What changed — paradigm shift

The final project has been redesigned. The OLD approach (deprecated) asked
students to pick a new city and run analysis on a different county. That
required significant R troubleshooting and is no longer the assignment.

THE NEW APPROACH:
- Geography is FIXED: Arizona / Maricopa County for all students
- Students do ONE code change: uncomment 1–4 lines in the index-config chunk
- The dashboard auto-recomputes everything with an expanded EHI
- Students compare the new results visually against the instructor dashboard
- Students write reflections on index sensitivity and policy implications

### Deprecated files — DO NOT TOUCH OR REFERENCE
All files in FinalDashboard/StudentExample/ that are not
Final_Project_Student.qmd should be ignored. The old San Diego files
and the old Final_Project_Template_student files are replaced entirely.

### The ONE student file
  FinalDashboard/StudentExample/Final_Project_Student.qmd

This file has already been placed in the repo. It contains:
- Tab 1: National Context (US county choropleth + AZ table + dot plot)
- Tab 2: Arizona in Focus (AZ tracts EHI map + scatter + LISA map + table)
- Tab 3: Maricopa: Clusters & Trajectories (Sankey + trajectory map + vboxes)
- Tab 4: Policy Implications (auto-stats cards + 3 recommendation TODOs)
- Tab 5: Index Sensitivity (NEW — 3 reflection questions about index composition)

### What students actually do

In the index-config chunk (~lines 55–80), students uncomment lines:

  STUDENT_COMPONENTS <- c(
  #   "renter_rate",       # Option A — Renter Burden
  #   "no_hs_rate",        # Option B — Low Educational Attainment
  #   "snap_rate",         # Option C — Food Insecurity (SNAP)
  #   "no_vehicle_rate"    # Option D — Transportation Disadvantage
  )

They uncomment 1 or more lines, re-render, and observe how the spatial
patterns change. Then they write answers to the Index Sensitivity questions
and the 3 Policy Implication TODOs.

NO OTHER CODE CHANGES ARE REQUIRED OR EXPECTED.

### The instructor dashboard (reference)
  FinalDashboard/Dashboard/Final_Project_Template.qmd (3-variable baseline)
  FinalDashboard/Dashboard/Final_Project_Template.html

Students compare their expanded-index results against this baseline.

---

## TASK 1 — Render the student dashboard

File to render:
  FinalDashboard/StudentExample/Final_Project_Student.qmd

First check the file exists and read it to understand the current state.
Then render with default settings (all STUDENT_COMPONENTS commented out = 
baseline 3-variable index):

  CENSUS_API_KEY=$(grep CENSUS_API_KEY ~/.Renviron | head -1 | \
    cut -d= -f2 | tr -d '"')
  CENSUS_API_KEY=$CENSUS_API_KEY \
    /Applications/RStudio.app/Contents/Resources/app/quarto/bin/quarto \
    render FinalDashboard/StudentExample/Final_Project_Student.qmd \
    2>&1 | tail -30

KNOWN ISSUE: The file uses htmlwidgets::onRender() for map legends.
If ANY map panel is blank/white after render, remove ALL onRender() 
blocks from the QMD (they are cosmetic only — the map data still renders
without them). Then re-render.

If render fails for any other reason, fix inline and continue.
Do NOT ask permission to fix errors.

After successful render:
  ls -lh FinalDashboard/StudentExample/Final_Project_Student.html

---

## TASK 2 — Create the FinalDashboard study guide

Create a new file:
  FinalDashboard/StudentExample/Final_Project_Guide.qmd

This is the student instructions page. It should render to a clean,
readable HTML document (NOT a dashboard — use format: html).

Content to include (write this in full, do not use placeholders):

### Section 1: Overview
Title: "PAF 516 Final Project: Economic Hardship Index Sensitivity Analysis"

Opening paragraph explaining:
The final project asks you to expand a baseline Economic Hardship Index (EHI)
by adding 1-4 additional indicators and analyze how the spatial patterns,
hot spot clusters, and policy implications change. This is fundamentally an
exercise in measurement sensitivity analysis — a core skill in applied
policy research.

### Section 2: Why index construction matters for policy
3-4 paragraphs covering:
- Composite indices are unavoidably political: which indicators you include
  determines which communities appear "hardship-affected" and which don't
- The Capability Approach (Sen/Nussbaum): poverty is multidimensional; 
  single-indicator measures systematically under-identify disadvantage
- Real-world stakes: CDFI Fund, HUD, EPA Justice40 all use composite indices
  to allocate billions in federal resources; index composition determines who
  gets funding
- The "tyranny of indicators": O'Neil (Weapons of Math Destruction) — when
  an index becomes a policy target it can be gamed or can systematically
  exclude the most vulnerable

### Section 3: What you are doing and why it is essentially no-code
Explain clearly:
- The baseline dashboard (instructor version, 3 variables) is already live
- Your student dashboard is identical code but with 4 additional variables
  commented out in the index-config chunk
- All you do is remove the # from 1-4 lines and re-render
- Everything else — all Census API pulls, all maps, all LISA analysis,
  all trajectory detection, all value boxes — updates automatically
- This is intentional: it lets you focus on interpreting substantive changes
  in spatial patterns rather than debugging code

### Section 4: Step-by-step instructions
1. Download the student QMD file (link below)
2. Open it in RStudio
3. Find the STUDENT CONFIGURATION block (around line 55)
4. Uncomment at least one option (remove the # from 1–4 lines)
5. Save the file
6. Delete the _cache/ folder next to the file (important! prevents stale data)
7. Click Render in RStudio
8. Wait ~5–10 minutes for Census API pulls to complete
9. Open the HTML output and visually compare to the instructor dashboard

### Section 5: Comparison guide
What to look for when comparing:
- National Context tab: Does your county's national rank change?
- Arizona in Focus tab: Does the spatial distribution of high-hardship tracts
  change? Which counties gained or lost hot spot status?
- Clusters & Trajectories tab: Do the Persistent HH corridors stay the same
  or shift? Does the Sankey show different mobility patterns?
- Policy Implications tab: Do the auto-computed values change meaningfully?

### Section 6: What you submit
1. Your rendered HTML file (the student dashboard with expanded index)
2. Completed answers in the Index Sensitivity tab (3 questions)
3. Completed policy recommendations in the Policy Implications tab (3 cards)
Note: You do NOT submit a separate policy brief. Everything is inside the
dashboard.

### Section 7: Advanced option (optional, not required)
For students comfortable with R who want to explore a different geography,
instructions explaining it IS possible but requires:
- Changing TARGET_STATE and TARGET_COUNTY (3 lines)  
- Deleting cache folders
- Debugging potential tidycensus county name ambiguity errors
- Updating hardcoded Arizona bounding boxes in the mapgl calls
Recommend sticking with AZ/Maricopa and focusing on index sensitivity.

### Download links section
Include clear links to:
  Instructor Dashboard (reference): ../Dashboard/Final_Project_Template.html
  Student Dashboard QMD (download): Final_Project_Student.qmd

Render the guide:
  /Applications/RStudio.app/Contents/Resources/app/quarto/bin/quarto \
    render FinalDashboard/StudentExample/Final_Project_Guide.qmd

---

## TASK 3 — Update the landing page (docs/index.html)

The landing page needs a completely new Final Project section.
Remove all old references to:
- Policy Brief
- San Diego example
- "choose any county"
- Module7_Guide links

Replace the Final Project section with THREE items:

1. INSTRUCTOR DASHBOARD EXAMPLE
   Link: Final_Project_Complete.html (already in docs/)
   Description: "3-variable baseline Economic Hardship Index — Maricopa County, AZ.
   Use this as your reference when comparing your expanded-index results."

2. STUDENT INSTRUCTIONS
   Link: FinalDashboard/StudentExample/Final_Project_Guide.html
   Description: "Read before starting. Explains the assignment, the measurement
   sensitivity analysis framework, and step-by-step instructions."

3. STUDENT DASHBOARD (DOWNLOAD)
   Link: FinalDashboard/StudentExample/Final_Project_Student.qmd
   Description: "Download this QMD file. Uncomment 1–4 index components,
   render, compare results to the instructor dashboard, and write your analysis."

Style these consistently with the existing landing page card format.

---

## TASK 4 — Copy files to docs/ for GitHub Pages

  # Student guide HTML
  cp FinalDashboard/StudentExample/Final_Project_Guide.html \
     docs/Final_Project_Guide.html

  # Confirm instructor HTML is current
  cp FinalDashboard/Dashboard/Final_Project_Template.html \
     docs/Final_Project_Complete.html

---

## TASK 5 — Commit everything

  rm -rf FinalDashboard/StudentExample/*_files/
  rm -rf FinalDashboard/StudentExample/*_cache/
  rm -rf FinalDashboard/Dashboard/*_files/

  git add \
    FinalDashboard/StudentExample/Final_Project_Student.qmd \
    FinalDashboard/StudentExample/Final_Project_Student.html \
    FinalDashboard/StudentExample/Final_Project_Guide.qmd \
    FinalDashboard/StudentExample/Final_Project_Guide.html \
    docs/Final_Project_Complete.html \
    docs/Final_Project_Guide.html \
    docs/index.html

  git -c trailer.ifexists=doNothing commit -m \
    "Final project: new index-sensitivity paradigm, student guide, updated landing page"
  git push

  echo "=== DONE ==="
  git log --oneline -3
  echo ""
  echo "Live at: https://antjam-howell.github.io/paf-516-labs/"
