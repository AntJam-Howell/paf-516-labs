# Agent 1 — Build Dashboard Template

Build FinalDashboard/Dashboard/Final_Project_Template.qmd from scratch.

Before writing a single line:
  1. Read Pipeline/ORCHESTRATOR.md — all rules apply
  2. Read Lab5/Assignment/Lab5_Assignment.qmd — pooled standardization pattern
  3. Read Lab6/Assignment/Lab6_Assignment.qmd — trajectory classification pattern
  4. Read Lab4/Assignment/Lab4_Assignment.qmd — LISA pattern

---

## Setup

  mkdir -p FinalDashboard/Dashboard
  mkdir -p FinalDashboard/NoAPI/data
  mkdir -p FinalDashboard/StudentExample/data

---

## Complete QMD to write

Write every chunk in full — no placeholders, no "TODO: add code here".
The template must render out of the box for Maricopa County with zero
student code modifications (only TARGET_* parameter changes).

### YAML

```yaml
---
title: "Economic Hardship Dashboard"
subtitle: "`r TARGET_LABEL`"
format:
  dashboard:
    theme:
      - darkly
      - ../../assets/dashboard-theme.scss
    orientation: columns
    embed-resources: true
execute:
  echo: false
  warning: false
  message: false
---
```

### Chunk: setup
```r
#| label: setup
#| include: false
options(tigris_use_cache = TRUE)
options(tigris_progress_bar = FALSE)
set.seed(42)
```

### Chunk: packages
```r
#| label: packages
#| include: false
if (!file.exists("~/.paf516_ready")) {
  if (!requireNamespace("renv", quietly = TRUE)) install.packages("renv")
  tmp <- tempfile(fileext = ".lock")
  download.file(
    url      = "https://raw.githubusercontent.com/AntJam-Howell/paf-516-labs/main/renv.lock",
    destfile = tmp, mode = "wb"
  )
  renv::restore(lockfile = tmp, prompt = FALSE)
  file.create("~/.paf516_ready")
}
library(tidyverse); library(tidycensus); library(sf); library(spdep)
library(viridis); library(patchwork); library(biscale); library(mapgl); library(DT)
library(scales)
```

### Chunk: county-config  ← FIRST visible content
```r
#| label: county-config
# ── STUDENT: change only these 3 lines, then re-render ──────────────────
# Examples of other metros:
#   Los Angeles:      TARGET_STATE="CA", TARGET_COUNTY="Los Angeles",  TARGET_LABEL="Los Angeles County, CA"
#   Cook (Chicago):   TARGET_STATE="IL", TARGET_COUNTY="Cook",         TARGET_LABEL="Cook County, IL"
#   Miami-Dade:       TARGET_STATE="FL", TARGET_COUNTY="Miami-Dade",   TARGET_LABEL="Miami-Dade County, FL"
#   King (Seattle):   TARGET_STATE="WA", TARGET_COUNTY="King",         TARGET_LABEL="King County, WA"
#   Harris (Houston): TARGET_STATE="TX", TARGET_COUNTY="Harris",       TARGET_LABEL="Harris County, TX"
TARGET_STATE  <- "AZ"
TARGET_COUNTY <- "Maricopa"
TARGET_LABEL  <- "Maricopa County, AZ"
# ─────────────────────────────────────────────────────────────────────────
```

### Chunk: index-config
```r
#| label: index-config
hardship_vars <- c(
  pov_below50   = "C17002_002",
  pov_50to99    = "C17002_003",
  pov_den       = "C17002_001",
  unemp_num     = "B23025_005",
  unemp_den     = "B23025_002",
  median_income = "B19013_001"
)
renter_vars <- c(
  renter_num = "B25003_003",
  renter_den = "B25003_001"
)

build_hardship_index <- function(raw_df) {
  raw_df %>%
    select(-moe) %>%
    pivot_wider(names_from = variable, values_from = estimate) %>%
    mutate(
      poverty_rate = (pov_below50 + pov_50to99) / pov_den,
      unemp_rate   = unemp_num / unemp_den
    ) %>%
    filter(!is.na(poverty_rate), !is.na(unemp_rate), !is.na(median_income)) %>%
    (function(df) {
      geom <- if (inherits(df, "sf")) st_geometry(df) else NULL
      tbl  <- st_drop_geometry(df)
      z_pov  <- as.numeric(scale(tbl$poverty_rate))
      z_unemp <- as.numeric(scale(tbl$unemp_rate))
      z_inc  <- -1 * as.numeric(scale(tbl$median_income))
      tbl$hardship_index <- rowMeans(cbind(z_pov, z_unemp, z_inc), na.rm = TRUE)
      if (!is.null(geom)) st_sf(tbl, geometry = geom) else tbl
    })()
}
```

### Chunk: pull-national
```r
#| label: pull-national
#| cache: true
county_raw <- get_acs(
  geography    = "county",
  variables    = hardship_vars,
  year         = 2023,
  survey       = "acs5",
  geometry     = TRUE,
  progress_bar = FALSE
)
county_2023 <- build_hardship_index(county_raw)
```

### Chunk: pull-local-current
```r
#| label: pull-local-current
#| cache: true
local_combined_raw <- get_acs(
  geography    = "tract",
  variables    = c(hardship_vars, renter_vars),
  state        = TARGET_STATE,
  county       = TARGET_COUNTY,
  year         = 2023,
  survey       = "acs5",
  geometry     = TRUE,
  progress_bar = FALSE
)
# Split: hardship index
local_2023 <- build_hardship_index(
  local_combined_raw %>% filter(variable %in% names(hardship_vars))
)
# Renter rate join
renter_tbl <- local_combined_raw %>%
  filter(variable %in% names(renter_vars)) %>%
  st_drop_geometry() %>% select(-moe) %>%
  pivot_wider(names_from = variable, values_from = estimate) %>%
  mutate(renter_rate = renter_num / renter_den) %>%
  select(GEOID, renter_rate)
local_2023 <- left_join(local_2023, renter_tbl, by = "GEOID")
```

### Chunk: pull-temporal
```r
#| label: pull-temporal
#| cache: true
local_2013_raw <- get_acs(
  geography = "tract", variables = hardship_vars,
  state = TARGET_STATE, county = TARGET_COUNTY,
  year = 2013, survey = "acs5", geometry = TRUE, progress_bar = FALSE
)
local_2019_raw <- get_acs(
  geography = "tract", variables = hardship_vars,
  state = TARGET_STATE, county = TARGET_COUNTY,
  year = 2019, survey = "acs5", geometry = TRUE, progress_bar = FALSE
)
local_2016_raw <- get_acs(
  geography = "tract", variables = hardship_vars,
  state = TARGET_STATE, county = TARGET_COUNTY,
  year = 2016, survey = "acs5", geometry = FALSE, progress_bar = FALSE
)
```

### Chunk: pooled-std
```r
#| label: pooled-std
widen_and_rate <- function(df) {
  df %>%
    select(-moe) %>%
    pivot_wider(names_from = variable, values_from = estimate) %>%
    mutate(
      poverty_rate = (pov_below50 + pov_50to99) / pov_den,
      unemp_rate   = unemp_num / unemp_den
    ) %>%
    filter(!is.na(poverty_rate), !is.na(unemp_rate), !is.na(median_income))
}

local_2013_wide <- widen_and_rate(local_2013_raw)
local_2019_wide <- widen_and_rate(local_2019_raw)

r2013 <- local_2013_wide %>% st_drop_geometry() %>%
  select(GEOID, poverty_rate, unemp_rate, median_income)
r2019 <- local_2019_wide %>% st_drop_geometry() %>%
  select(GEOID, poverty_rate, unemp_rate, median_income)

vars_pool <- c("poverty_rate", "unemp_rate", "median_income")
pooled_stats <- map_dfr(vars_pool, function(v) {
  vals <- c(r2013[[v]], r2019[[v]])
  tibble(variable = v, mean = mean(vals, na.rm = TRUE), sd = sd(vals, na.rm = TRUE))
})

apply_pooled_z <- function(df, stats) {
  for (v in stats$variable) {
    df[[paste0("z_", v)]] <- (df[[v]] - stats$mean[stats$variable==v]) /
                              stats$sd[stats$variable==v]
  }
  df$z_median_income <- -1 * df$z_median_income
  df$hardship_index  <- rowMeans(
    df[, c("z_poverty_rate","z_unemp_rate","z_median_income")], na.rm = TRUE)
  df
}

r2013_z <- apply_pooled_z(r2013, pooled_stats)
r2019_z <- apply_pooled_z(r2019, pooled_stats)

change_df <- local_2019_wide %>%
  select(GEOID, NAME) %>%
  left_join(r2019_z %>% select(GEOID, hardship_2019 = hardship_index), by = "GEOID") %>%
  inner_join(r2013_z %>% select(GEOID, hardship_2013 = hardship_index), by = "GEOID") %>%
  mutate(hardship_change = hardship_2019 - hardship_2013)

lo <- quantile(change_df$hardship_change, 0.02, na.rm = TRUE)
hi <- quantile(change_df$hardship_change, 0.98, na.rm = TRUE)
max_abs <- max(abs(lo), abs(hi))
change_df <- change_df %>%
  mutate(change_plot = pmax(pmin(hardship_change, max_abs), -max_abs))
```

### Chunk: lisa-analysis
```r
#| label: lisa-analysis
nb    <- poly2nb(change_df, queen = TRUE)
w     <- nb2listw(nb, style = "W", zero.policy = TRUE)
lisa  <- localmoran(change_df$hardship_2019, w, zero.policy = TRUE)
z19   <- scale(change_df$hardship_2019)[,1]
wz19  <- lag.listw(w, z19, zero.policy = TRUE)
p19   <- lisa[, "Pr(z != E(Ii))"]

change_df <- change_df %>%
  mutate(lisa_2019 = case_when(
    z19 > 0 & wz19 > 0 & p19 < 0.05 ~ "HH",
    z19 < 0 & wz19 < 0 & p19 < 0.05 ~ "LL",
    z19 > 0 & wz19 < 0 & p19 < 0.05 ~ "HL",
    z19 < 0 & wz19 > 0 & p19 < 0.05 ~ "LH",
    TRUE ~ "NS"
  ))
```

### Chunk: trajectories
```r
#| label: trajectories
lisa_2013  <- localmoran(change_df$hardship_2013, w, zero.policy = TRUE)
z13  <- scale(change_df$hardship_2013)[,1]
wz13 <- lag.listw(w, z13, zero.policy = TRUE)
p13  <- lisa_2013[, "Pr(z != E(Ii))"]

local_2016_wide <- widen_and_rate(local_2016_raw %>% mutate(geometry = NULL))
r2016_z <- apply_pooled_z(
  local_2016_wide %>% select(GEOID, poverty_rate, unemp_rate, median_income),
  pooled_stats
)

change_df <- change_df %>%
  mutate(
    lisa_2013 = case_when(
      z13 > 0 & wz13 > 0 & p13 < 0.05 ~ "HH",
      z13 < 0 & wz13 < 0 & p13 < 0.05 ~ "LL",
      z13 > 0 & wz13 < 0 & p13 < 0.05 ~ "HL",
      z13 < 0 & wz13 > 0 & p13 < 0.05 ~ "LH",
      TRUE ~ "NS"
    ),
    trajectory = case_when(
      lisa_2013 == "HH" & lisa_2019 == "HH" ~ "Persistent HH",
      lisa_2013 != "HH" & lisa_2019 == "HH" ~ "Emerging HH",
      lisa_2013 == "HH" & lisa_2019 != "HH" ~ "Dissolving HH",
      lisa_2013 == "LL" & lisa_2019 == "LL" ~ "Persistent LL",
      lisa_2013 != "LL" & lisa_2019 == "LL" ~ "Emerging LL",
      lisa_2013 == "HL" | lisa_2019 == "HL" ~ "HL Outlier",
      TRUE                                   ~ "Stable NS"
    )
  ) %>%
  left_join(r2016_z %>% select(GEOID, hardship_2016 = hardship_index), by = "GEOID") %>%
  mutate(trend_type = case_when(
    hardship_2013 > hardship_2016 & hardship_2016 > hardship_2019 ~ "Consistently improving",
    hardship_2013 < hardship_2016 & hardship_2016 < hardship_2019 ~ "Consistently worsening",
    hardship_2013 > hardship_2016 & hardship_2016 < hardship_2019 ~ "V-shaped (improved mid)",
    hardship_2013 < hardship_2016 & hardship_2016 > hardship_2019 ~ "Inverted-V (worsened mid)",
    TRUE ~ "Flat / non-monotone"
  ))
```

### Chunk: summary-stats
```r
#| label: summary-stats
moran_global <- moran.test(change_df$hardship_2019, w, zero.policy = TRUE)
moran_chg    <- moran.mc(change_df$hardship_change, w, nsim = 499, zero.policy = TRUE)

n_hh <- sum(change_df$lisa_2019 == "HH", na.rm = TRUE)
n_ll <- sum(change_df$lisa_2019 == "LL", na.rm = TRUE)
n_total <- nrow(change_df)
pct_improved    <- round(100 * mean(change_df$hardship_change < -0.05, na.rm=TRUE), 1)
pct_worsened    <- round(100 * mean(change_df$hardship_change >  0.05, na.rm=TRUE), 1)
pct_persist_hh  <- round(100 * mean(change_df$trajectory == "Persistent HH", na.rm=TRUE), 1)
pct_emerg_hh    <- round(100 * mean(change_df$trajectory == "Emerging HH",   na.rm=TRUE), 1)

county_hi <- county_2023 %>% st_drop_geometry() %>%
  filter(!is.na(hardship_index)) %>%
  slice_max(hardship_index, n = 1) %>%
  mutate(label = paste0(str_remove(NAME, ",.*"), " (", round(hardship_index,2), ")")) %>%
  pull(label)
n_counties <- sum(!is.na(county_2023$hardship_index))

traj_colors <- c(
  "Persistent HH"="#D7191C", "Emerging HH"="#FDAE61", "Dissolving HH"="#FEE08B",
  "Persistent LL"="#2C7BB6", "Emerging LL"="#ABD9E9", "HL Outlier"="#9E5BB4",
  "Stable NS"="#CCCCCC"
)
lisa_colors <- c("HH"="#D7191C","LL"="#2C7BB6","HL"="#FDAE61","LH"="#ABD9E9","NS"="#CCCCCC")
```

---

## Tab 1: National Context

```
# National Context

## Column {width=62%}

```{r}
#| label: map-national
county_4326 <- county_2023 %>% st_transform(4326) %>% filter(!is.na(hardship_index))
maplibre(
  bounds = st_bbox(county_4326),
  style  = maptiler_style("dataviz-dark")
) %>%
  add_fill_layer(
    id     = "counties",
    source = list(type = "geojson", data = county_4326),
    fill_color = interpolate(
      column   = "hardship_index",
      values   = c(min(county_4326$hardship_index), max(county_4326$hardship_index)),
      stops    = c("#313695","#74ADD1","#FFFFBF","#F46D43","#A50026"),
      na_color = "#333333"
    ),
    fill_opacity = 0.8,
    tooltip = c("NAME", "hardship_index")
  ) %>%
  add_legend(
    "Economic Hardship Index",
    values   = round(quantile(county_4326$hardship_index, c(0,0.25,0.5,0.75,1)), 2),
    colors   = c("#313695","#74ADD1","#FFFFBF","#F46D43","#A50026"),
    position = "bottom-left"
  )
```

## Column {width=38%}

```{r}
#| content: valuebox
list(title="Counties Mapped", value=comma(n_counties), icon="map")
```

```{r}
#| content: valuebox
list(title="Highest Hardship County", value=county_hi, icon="exclamation-triangle-fill", color="danger")
```

```{r}
#| content: valuebox
list(
  title = paste0(TARGET_LABEL, " National Rank"),
  value = {
    rank_val <- rank(-county_2023$hardship_index, na.last="keep", ties.method="min")
    target_geoid <- county_2023 %>%
      st_drop_geometry() %>%
      filter(str_detect(NAME, fixed(TARGET_COUNTY))) %>%
      slice(1)
    if(nrow(target_geoid) > 0) {
      r <- rank_val[which(county_2023$GEOID == target_geoid$GEOID[1])]
      paste0("#", r, " of ", n_counties)
    } else "—"
  },
  icon = "bar-chart-fill"
)
```

```{r}
#| label: table-national
county_2023 %>%
  st_drop_geometry() %>%
  filter(!is.na(hardship_index)) %>%
  arrange(desc(hardship_index)) %>%
  mutate(
    County   = str_remove(NAME, ", .+"),
    State    = str_extract(NAME, "(?<=, )[A-Z].+"),
    Hardship = round(hardship_index, 3)
  ) %>%
  select(County, State, Hardship) %>%
  head(20) %>%
  DT::datatable(options=list(pageLength=8, dom="tp"), rownames=FALSE)
```
```

---

## Tab 2: Local Hardship

```
# Local Hardship

## Column {width=50%}

```{r}
#| label: map-local
#| fig-height: 7
ggplot(local_2023) +
  geom_sf(aes(fill = hardship_index), color = NA) +
  scale_fill_viridis_c(option="inferno", direction=-1,
                       name="Hardship\nIndex", na.value="grey40") +
  theme_void(base_size=11) +
  labs(title    = paste0("Economic Hardship: ", TARGET_LABEL),
       subtitle = "Census tracts | ACS 2019–2023 5-Year",
       caption  = "3-variable index: poverty rate, unemployment rate, median income (reversed)")
```

## Column {width=50%}

```{r}
#| label: map-bivariate
#| fig-height: 7
bi_data <- local_2023 %>%
  filter(!is.na(hardship_index), !is.na(renter_rate)) %>%
  bi_class(x=hardship_index, y=renter_rate, style="quantile", dim=3)

p_bi <- ggplot(bi_data) +
  geom_sf(aes(fill=bi_class), color=NA, show.legend=FALSE) +
  bi_scale_fill(pal="DkBlue", dim=3) +
  theme_void(base_size=11) +
  labs(title    = "Hardship × Renter Rate",
       subtitle = paste0(TARGET_LABEL, " | ACS 2019–2023"),
       caption  = "Dark blue = high hardship AND high renter rate")

p_legend <- bi_legend(pal="DkBlue", dim=3,
                       xlab="Hardship →", ylab="% Renter →", size=9)

p_bi + inset_element(p_legend, left=0.72, bottom=0.05, right=1, top=0.35)
```
```

---

## Tab 3: Hot Spots

```
# Hot Spots

## Column {width=60%}

```{r}
#| label: map-lisa
#| fig-height: 8
ggplot(change_df) +
  geom_sf(aes(fill=lisa_2019), color=NA) +
  scale_fill_manual(values=lisa_colors,
    labels=c("HH"="Hot Spot (HH)","LL"="Cold Spot (LL)",
             "HL"="High-Low Outlier","LH"="Low-High Outlier","NS"="Not Significant"),
    name="LISA Cluster\n(2019, p<0.05)") +
  theme_void(base_size=11) +
  labs(title    = paste0("Spatial Hardship Clusters: ", TARGET_LABEL),
       subtitle = "LISA analysis on 2015–2019 ACS economic hardship index",
       caption  = paste0("Global Moran's I = ", round(moran_global$estimate[1],3),
                         " (p < 0.001) — significant positive spatial autocorrelation"))
```

## Column {width=40%}

```{r}
#| content: valuebox
list(title="Hot Spot Tracts (HH)", value=n_hh, icon="fire", color="danger")
```

```{r}
#| content: valuebox
list(title="Cold Spot Tracts (LL)", value=n_ll, icon="snow", color="primary")
```

```{r}
#| content: valuebox
list(title="Global Moran's I", value=round(moran_global$estimate[1],3),
     icon="diagram-3", color="secondary")
```

```{r}
#| label: table-hotspots
change_df %>%
  st_drop_geometry() %>%
  filter(lisa_2019 %in% c("HH","LL")) %>%
  arrange(desc(hardship_2019)) %>%
  mutate(
    Tract    = str_extract(NAME, "Census Tract [\\d\\.]+"),
    Cluster  = lisa_2019,
    Hardship = round(hardship_2019, 3),
    Trajectory = trajectory
  ) %>%
  select(Tract, Cluster, Hardship, Trajectory) %>%
  DT::datatable(options=list(pageLength=10, dom="tp"), rownames=FALSE)
```
```

---

## Tab 4: Change & Trajectories

```
# Change & Trajectories

## Column {width=50%}

```{r}
#| label: map-trajectory
#| fig-height: 8
ggplot(change_df) +
  geom_sf(aes(fill=trajectory), color=NA) +
  scale_fill_manual(values=traj_colors,
    labels=c("Persistent HH"="Persistent Hot Spot",
             "Emerging HH"  ="Emerging Hot Spot",
             "Dissolving HH"="Dissolving Hot Spot",
             "Persistent LL"="Persistent Cold Spot",
             "Emerging LL"  ="Emerging Cold Spot",
             "HL Outlier"   ="Spatial Outlier",
             "Stable NS"    ="No Dominant Pattern"),
    name="Trajectory\n(2013→2019)") +
  theme_void(base_size=11) +
  labs(title    = paste0("Neighborhood Hardship Trajectories: ", TARGET_LABEL),
       subtitle = "LISA cluster transition, 2013–2019 | Pooled z-score standardization",
       caption  = "Pooled mean/SD across both years — comparable change scores")
```

## Column {width=50%}

```{r}
#| content: valuebox
list(title="Tracts Improved (2013→2019)", value=paste0(pct_improved,"%"),
     icon="arrow-down-circle", color="success")
```

```{r}
#| content: valuebox
list(title="Persistently High Hardship", value=paste0(pct_persist_hh,"%"),
     icon="exclamation-circle", color="danger")
```

```{r}
#| content: valuebox
list(title="Emerging Hot Spots", value=paste0(pct_emerg_hh,"%"),
     icon="arrow-up-right-circle", color="warning")
```

```{r}
#| label: map-change
#| fig-height: 5.5
ggplot(change_df) +
  geom_sf(aes(fill=change_plot), color=NA) +
  scale_fill_gradient2(low="#2C7BB6", mid="white", high="#D7191C",
    midpoint=0, limits=c(-max_abs, max_abs), name="Hardship\nChange") +
  theme_void(base_size=10) +
  labs(title    = paste0("Hardship Change (2013→2019): ", TARGET_LABEL),
       subtitle = "Blue = improved | Red = worsened | Winsorized at 2nd/98th pct")
```
```

---

## Tab 5: Policy

```
# Policy

## Column {width=55%}

```{r}
#| label: table-policy
change_df %>%
  st_drop_geometry() %>%
  filter(trajectory %in% c("Persistent HH","Emerging HH")) %>%
  arrange(desc(hardship_2019)) %>%
  mutate(
    Tract        = str_extract(NAME, "Census Tract [\\d\\.]+"),
    Trajectory   = trajectory,
    `Hardship 2019` = round(hardship_2019, 3),
    `Change 2013–19` = round(hardship_change, 3)
  ) %>%
  select(Tract, Trajectory, `Hardship 2019`, `Change 2013–19`) %>%
  DT::datatable(
    filter  = "top",
    options = list(pageLength=12, dom="ftp"),
    rownames = FALSE
  )
```

## Column {width=45%}

::: {.card}
## Recommendation 1
**TODO:** Write your first recommendation targeting Persistent HH tracts
— neighborhoods with entrenched, long-standing hardship clusters.
Name a specific geography, cite the hardship score, and propose a
concrete intervention with a responsible entity.

*[Your answer here — minimum 3 sentences]*
:::

::: {.card}
## Recommendation 2
**TODO:** Write your second recommendation targeting Emerging HH tracts
— neighborhoods where spatial clustering of hardship is newly forming.
Reference the change score and consider displacement risk.

*[Your answer here — minimum 3 sentences]*
:::

::: {.card}
## Recommendation 3
**TODO:** Write your third recommendation using the temporal evidence
— the trajectory map, change scores, and space-time Moran's I statistic.
Make a forward-looking data-monitoring or early-intervention argument.

*[Your answer here — minimum 3 sentences]*
:::
```

---

## After writing

1. Verify no banned content:
   grep -c "B15003_002\|psych::alpha\|crosstalk\|SharedData\|year.*2015\|leaflet" \
     FinalDashboard/Dashboard/Final_Project_Template.qmd
   (expect: 0)

2. Verify mapgl only on National Context tab:
   grep -n "maplibre\|mapboxgl\|add_fill_layer" \
     FinalDashboard/Dashboard/Final_Project_Template.qmd

3. Render:
   CENSUS_API_KEY=$(grep CENSUS_API_KEY ~/.Renviron | head -1 | cut -d= -f2 | tr -d '"')
   cd FinalDashboard/Dashboard
   CENSUS_API_KEY=$CENSUS_API_KEY \
     /Applications/RStudio.app/Contents/Resources/app/quarto/bin/quarto \
     render Final_Project_Template.qmd 2>&1 | tail -15
   cd ../..

4. Check no _files/ folder:
   ls FinalDashboard/Dashboard/ | grep _files && echo "FAIL" || echo "PASS"

5. Check file size:
   ls -lh FinalDashboard/Dashboard/Final_Project_Template.html

6. Report: render pass/fail, size, any errors
   ⛔ STOP — do not proceed to Agent 2 until reporting
